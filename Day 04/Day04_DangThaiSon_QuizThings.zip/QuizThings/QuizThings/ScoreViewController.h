//
//  ScoreViewController.h
//  QuizThings
//
//  Created by SonDT on 6/24/14.
//  Copyright (c) 2014 Techmaster. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScoreViewController : UIViewController
@property (nonatomic, assign) int score;
@end
