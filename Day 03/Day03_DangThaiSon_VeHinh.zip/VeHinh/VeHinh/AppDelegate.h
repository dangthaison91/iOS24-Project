//
//  AppDelegate.h
//  VeHinh
//
//  Created by SonDT on 6/19/14.
//  Copyright (c) 2014 SonDT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
